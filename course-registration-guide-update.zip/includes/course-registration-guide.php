<?php
/** Plain-text source document and versioned enrollment acknowledgment. */
function courseRegistrationGuide(array $course): ?array
{
    if (strtolower(trim((string) ($course['slug'] ?? ''))) !== 'website-development-for-beginners') return null;
    $path = dirname(__DIR__) . '/assets/data/website-development-registration-guide.json';
    $source = file_get_contents($path);
    if ($source === false) throw new RuntimeException('Course registration guide is unavailable.');
    $blocks = json_decode($source, true, 512, JSON_THROW_ON_ERROR);
    return ['version' => hash('sha256', $source), 'blocks' => $blocks];
}

function validCourseGuideAcknowledgment(?array $guide, array $data): bool
{
    return $guide === null || (($data['guide_accepted'] ?? null) === true
        && is_string($data['guide_version'] ?? null)
        && hash_equals($guide['version'], $data['guide_version']));
}

function recordCourseGuideAcknowledgment(Database $db, int $studentId, int $courseId, array $guide): void
{
    $db->query('INSERT INTO course_registration_acknowledgments (student_id, course_id, guide_version, accepted_at)
                VALUES (:student_id, :course_id, :guide_version, NOW())
                ON DUPLICATE KEY UPDATE id = id');
    $db->bind(':student_id', $studentId);
    $db->bind(':course_id', $courseId);
    $db->bind(':guide_version', $guide['version']);
    $db->execute();
}
